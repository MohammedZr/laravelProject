

<?php $__env->startSection('content'); ?>
  <a href="<?php echo e(route('company.orders.index')); ?>"
     class="inline-block mb-4 rounded-xl border-2 border-[var(--ink)] px-3 py-2 hover:bg-[var(--line)]/60 text-sm">
    ← رجوع للطلبات
  </a>

  <div class="rounded-2xl border-2 border-[var(--ink)] bg-[var(--bg-card)] shadow-soft p-4">
    
    <div class="flex items-center justify-between">
      <div class="text-xl text-[var(--brand-ink)] font-semibold">
        طلب #<?php echo e($order->id); ?>

      </div>
      <span class="text-xs rounded-lg border-2 border-[var(--ink)] px-2 py-0.5 bg-[var(--bg-page)]">
        <?php echo e(__("statuses.$order->status") ?? $order->status); ?>

      </span>
    </div>

    
    <div class="grid sm:grid-cols-2 gap-4 mt-4 text-sm">
      <div>
        <div class="text-[var(--muted)]">الصيدلية</div>
        <div><?php echo e(optional($order->pharmacy)->name ?? '—'); ?></div>
        <div class="text-[var(--muted)]"><?php echo e(optional($order->pharmacy)->email ?? ''); ?></div>
      </div>
      <div>
        <div class="text-[var(--muted)]">تاريخ الإنشاء</div>
        <div><?php echo e($order->created_at?->format('Y-m-d H:i')); ?></div>
        <div class="text-[var(--muted)] mt-2">الإجمالي</div>
        <div><?php echo e(number_format($order->total_amount, 2)); ?></div>
      </div>
    </div>

    
    <div class="mt-6">
      <div class="text-[var(--brand-ink)] font-semibold mb-2">عناصر الطلب</div>
      <div class="divide-y divide-[var(--line)]">
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="py-3 flex items-center gap-3">
            <?php $img = $item->drug->image_url ?? null; ?>
            <?php if($img): ?>
              <img src="<?php echo e($img); ?>" class="h-14 w-14 rounded-xl object-cover border-2 border-[var(--ink)]" alt="">
            <?php else: ?>
              <div class="h-14 w-14 rounded-xl border-2 border-[var(--ink)] bg-[var(--bg-page)]"></div>
            <?php endif; ?>

            <div class="flex-1 min-w-0">
              <div class="truncate text-[var(--ink)]">
                <?php echo e($item->drug->name ?? '—'); ?>

              </div>
              <div class="text-xs text-[var(--muted)] truncate">
                <?php echo e($item->drug->generic_name ?? ''); ?>

              </div>
            </div>

            <div class="text-sm text-[var(--muted)] whitespace-nowrap">
              x<?php echo e($item->quantity); ?>

            </div>
            <div class="text-sm text-[var(--muted)] whitespace-nowrap">
              <?php echo e(number_format($item->unit_price, 2)); ?>

            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>

    
    <div class="mt-6 border-t border-[var(--line)] pt-4 flex flex-col lg:flex-row gap-3 lg:items-center lg:justify-between">
      <form method="POST" action="<?php echo e(route('company.orders.updateStatus', $order)); ?>" class="flex items-center gap-2">
        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
        <select name="status" class="input w-56 border-2 border-[var(--ink)]">
          <?php $__currentLoopData = [
              'pending'          => 'قيد المراجعة',
              'confirmed'        => 'تم التأكيد',
              'preparing'        => 'جارِ التجهيز',
              'out_for_delivery' => 'خرج للتسليم',
              'completed'        => 'مكتمل',
              'cancelled'        => 'ملغي',
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php if($order->status===$key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn h-11 px-4 rounded-xl">تحديث الحالة</button>
      </form>

      <div class="text-lg text-[var(--brand-ink)] font-semibold">
        الإجمالي: <?php echo e(number_format($order->total_amount, 2)); ?>

      </div>
    </div>

    
    <?php
      $couriers = \App\Models\User::where('role','delivery')
                  ->where('company_id', auth()->id())
                  ->orderBy('name')
                  ->get();
    ?>

    <div class="mt-6 rounded-2xl border-2 border-[var(--ink)] p-4">
      <div class="text-[var(--brand-ink)] font-semibold mb-3">إسناد الطلب لمنذوب</div>

      <?php if(session('ok')): ?>
        <div class="mb-3 rounded-xl border-2 border-[var(--ink)] bg-[var(--bg-page)] px-3 py-2 text-sm">
          <?php echo e(session('ok')); ?>

        </div>
      <?php endif; ?>

      <?php if($couriers->isEmpty()): ?>
        <div class="text-[var(--muted)] text-sm">
          لا يوجد مناديب مضافة لهذه الشركة.
          أضف مستخدمين بدور <b>delivery</b> واجعل <code>company_id</code> لهم = <?php echo e(auth()->id()); ?>.
        </div>
      <?php else: ?>
        <form method="POST" action="<?php echo e(route('company.orders.assign', $order)); ?>"
              class="flex flex-col sm:flex-row gap-2">
          <?php echo csrf_field(); ?>
          <select name="delivery_user_id" class="input w-full sm:w-64 border-2 border-[var(--ink)]" required>
            <option value="">اختر المنذوب...</option>
            <?php $__currentLoopData = $couriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($c->id); ?>" <?php if(optional($order->delivery)->delivery_user_id === $c->id): echo 'selected'; endif; ?>>
                <?php echo e($c->name); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>

          <input type="text" name="notes" class="input flex-1 border-2 border-[var(--ink)]"
                 value="<?php echo e(old('notes', optional($order->delivery)->notes)); ?>"
                 placeholder="ملاحظات للمنذوب (اختياري)">

          <button class="btn h-11 px-4 rounded-xl">إسناد</button>
        </form>

        <?php $__errorArgs = ['delivery_user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="mt-2 text-xs text-red-500"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <?php endif; ?>
    </div>

    
    <?php if($order->delivery): ?>
      <div class="mt-6 rounded-2xl border-2 border-[var(--ink)] p-4">
        <div class="text-[var(--brand-ink)] font-semibold mb-2">تفاصيل مهمة التوصيل</div>
        <div class="grid sm:grid-cols-2 gap-4 text-sm">
          <div>
            <div class="text-[var(--muted)]">المنذوب</div>
            <div><?php echo e(optional($order->delivery->courier)->name ?? '—'); ?></div>
          </div>
          <div>
            <div class="text-[var(--muted)]">حالة التسليم</div>
            <div><?php echo e($order->delivery->status); ?></div>
          </div>
          <div>
            <div class="text-[var(--muted)]">بداية التسليم</div>
            <div><?php echo e($order->delivery->picked_up_at?->format('Y-m-d H:i') ?? '—'); ?></div>
          </div>
          <div>
            <div class="text-[var(--muted)]">وقت التسليم</div>
            <div><?php echo e($order->delivery->delivered_at?->format('Y-m-d H:i') ?? '—'); ?></div>
          </div>
        </div>
        <?php if($order->delivery->notes): ?>
          <div class="mt-3 text-sm">
            <div class="text-[var(--muted)]">ملاحظات:</div>
            <div><?php echo e($order->delivery->notes); ?></div>
          </div>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', ['title' => $title ?? 'تفاصيل الطلب'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alzur\Desktop\Madness\learning laravel\Projects\Laravel\resources\views/company/orders/show.blade.php ENDPATH**/ ?>