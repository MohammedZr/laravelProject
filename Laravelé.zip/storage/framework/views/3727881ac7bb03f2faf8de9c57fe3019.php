

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="mb-4 rounded-lg border border-[var(--line)] bg-green-50 px-4 py-3 text-sm text-green-700">
      <?php echo e(session('status')); ?>

    </div>
  <?php endif; ?>

  
  <form method="GET" action="<?php echo e(route('pharmacy.search')); ?>"
        class="mx-auto mb-6 flex flex-wrap items-center justify-center gap-3"
        style="max-width: 720px">
    <input type="text" name="q" value="<?php echo e($q ?? ''); ?>"
           class="input w-full sm:w-[420px]"
           placeholder="ابحث بالاسم، المادة الفعّالة، الشكل، التركيز…">
    <select name="type" class="input w-36 sm:w-40">
      <option value="all"    <?php if(($type ?? 'all')==='all'): echo 'selected'; endif; ?>>الكل</option>
      <option value="name"   <?php if(($type ?? '')==='name'): echo 'selected'; endif; ?>>الاسم</option>
      <option value="generic"<?php if(($type ?? '')==='generic'): echo 'selected'; endif; ?>>التركيبة</option>
      <option value="form"   <?php if(($type ?? '')==='form'): echo 'selected'; endif; ?>>الشكل</option>
    </select>
    <button class="btn h-11 px-5 rounded-xl bg-[var(--brand)] text-white">بحث</button>
  </form>

  <?php if($drugs->count()): ?>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-5">
      <?php $__currentLoopData = $drugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="rounded-2xl border border-[var(--line)] bg-[var(--bg-card)] p-4 shadow-soft">
          <div class="flex items-start gap-4">
            
            <div class="shrink-0">
              <?php
                $img = $d->image_url ?? null;
              ?>
              <?php if($img): ?>
                <img src="<?php echo e($img); ?>" alt="صورة <?php echo e($d->name); ?>"
                     class="h-24 w-24 rounded-xl object-cover border border-[var(--line)]">
              <?php else: ?>
                
                <div class="h-24 w-24 rounded-xl border border-[var(--line)] bg-[var(--bg-page)] flex items-center justify-center">
                  <svg viewBox="0 0 24 24" class="h-10 w-10 text-[var(--muted)]" fill="none" stroke="currentColor" stroke-width="1.6">
                    <path d="M3 17l4-4 3 3 5-5 6 6" />
                    <circle cx="8.5" cy="8.5" r="1.5"/>
                  </svg>
                </div>
              <?php endif; ?>
            </div>

            
            <div class="flex-1 min-w-0">
              <div class="flex items-start justify-between gap-3">
                <div class="truncate">
                  <div class="text-base font-semibold text-[var(--brand-ink)] truncate"><?php echo e($d->name); ?></div>
                  <div class="text-sm text-[var(--muted)] truncate"><?php echo e($d->generic_name ?? '—'); ?></div>
                </div>
                <div class="text-xs text-[var(--muted)] text-right whitespace-nowrap">
                  <?php echo e($d->dosage_form ?? ''); ?> <?php echo e($d->strength ? '— '.$d->strength : ''); ?>

                </div>
              </div>

              <div class="mt-2 flex items-center justify-between">
                <div class="text-sm">
                  <span class="text-[var(--muted)]">السعر:</span>
                  <b><?php echo e(number_format($d->price, 2)); ?></b>
                </div>
                <div class="text-xs text-[var(--muted)]">المخزون: <?php echo e($d->stock); ?></div>
              </div>

              
              <form method="POST" action="<?php echo e(route('pharmacy.cart.add', $d)); ?>" class="mt-3 flex items-center gap-3">
                <?php echo csrf_field(); ?>
                <input type="number" name="quantity" min="1" value="1" class="input w-24">
                <button class="btn h-11 px-5 rounded-xl bg-[var(--brand)] text-white w-full sm:w-40">
                  أضف للسلة
                </button>
              </form>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-6"><?php echo e($drugs->links()); ?></div>
  <?php else: ?>
    <div class="text-center text-[var(--muted)] py-10">لا نتائج.</div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', ['title' => 'بحث الأدوية'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alzur\Desktop\Madness\learning laravel\Projects\Laravel\resources\views/pharmacy/search.blade.php ENDPATH**/ ?>