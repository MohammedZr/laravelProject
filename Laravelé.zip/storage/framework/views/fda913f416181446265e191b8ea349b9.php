

<?php $__env->startSection('content'); ?>
  <?php if(session('success')): ?>
    <div class="mb-4 rounded-xl border-2 border-[var(--ink)] bg-[var(--bg-card)] p-3 text-[var(--brand-ink)]">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

  <form method="GET" class="mb-4 flex items-center gap-2">
    <select name="status" class="input w-56">
      <option value="">كل الحالات</option>
      <?php $__currentLoopData = ['assigned'=>'مُسنَد','picked_up'=>'تم الاستلام','delivering'=>'قيد التوصيل','delivered'=>'تم التسليم','failed'=>'فشل']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($k); ?>" <?php if($status===$k): echo 'selected'; endif; ?>><?php echo e($v); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn h-11 px-4 rounded-xl">تصفية</button>
  </form>

  <?php if($orders->isEmpty()): ?>
    <div class="text-center text-[var(--muted)] py-16">لا توجد طلبيات معيّنة لك الآن.</div>
  <?php else: ?>
    <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="rounded-2xl border border-[var(--line)] bg-[var(--bg-card)] shadow-soft p-4">
          <div class="flex items-center justify-between">
            <div class="font-semibold text-[var(--brand-ink)]">طلب #<?php echo e($o->id); ?></div>
            <span class="text-xs rounded-lg border-2 border-[var(--ink)] px-2 py-0.5 bg-[var(--bg-page)]">
              <?php echo e($o->delivery->status ?? '—'); ?>

            </span>
          </div>
          <div class="mt-2 text-sm text-[var(--muted)]">
            <div>الصيدلية: <?php echo e($o->pharmacy->name ?? '—'); ?></div>
            <div>العنوان: <?php echo e($o->delivery_address ?? '—'); ?></div>
          </div>
          <div class="mt-3">
            <a href="<?php echo e(route('delivery.orders.show', $o)); ?>" class="rounded-xl border-2 border-[var(--ink)] px-3 py-2 inline-block hover:bg-[var(--line)]/60 text-sm">فتح</a>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="mt-6"><?php echo e($orders->links()); ?></div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', ['title' => $title ?? 'لوحة المندوب'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alzur\Desktop\Madness\learning laravel\Projects\Laravel\resources\views/delivery/dashboard.blade.php ENDPATH**/ ?>