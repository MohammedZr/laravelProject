

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="mb-4 rounded-lg border border-[var(--line)] bg-green-50 px-4 py-3 text-sm text-green-700">
      <?php echo e(session('status')); ?>

    </div>
  <?php endif; ?>

  <div class="flex items-center justify-between mb-4">
    <h1 class="text-xl font-bold text-[var(--brand-ink)]">سلة المشتريات</h1>
    <a href="<?php echo e(route('pharmacy.search')); ?>" class="text-[var(--brand-ink)] hover:underline">عودة للبحث</a>
  </div>

  <?php
    $hasAny = false;
  ?>

  <?php $__empty_1 = true; $__currentLoopData = $byCompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $companyId => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php
      $company = $items->first()->company;
      $total = $items->sum(fn($i) => $i->quantity * $i->unit_price);
      $hasAny = true;
    ?>

    <div class="mb-6 rounded-2xl border border-[var(--line)] bg-[var(--bg-card)] p-4 shadow-soft">
      <div class="flex items-center justify-between">
        <div>
          <div class="font-semibold text-[var(--ink)]">شركة: <?php echo e($company?->name ?? 'غير معروفة'); ?></div>
          <div class="text-sm text-[var(--muted)]">الإجمالي: <?php echo e(number_format($total, 2)); ?></div>
        </div>

        <form method="POST" action="<?php echo e(route('pharmacy.orders.checkout.company', $companyId)); ?>">
          <?php echo csrf_field(); ?>
          <button class="btn h-10 px-4 rounded-xl bg-[var(--brand)] text-white">إرسال طلبية لهذه الشركة</button>
        </form>
      </div>

      <div class="mt-4 overflow-x-auto">
        <table class="min-w-full text-sm">
          <thead class="text-[var(--muted)]">
            <tr class="border-b border-[var(--line)]">
              <th class="py-2 text-right">الدواء</th>
              <th class="py-2 text-right">السعر</th>
              <th class="py-2 text-right">الكمية</th>
              <th class="py-2 text-right">الإجمالي</th>
              <th class="py-2 text-right">إجراء</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="border-b border-[var(--line)]">
                <td class="py-2">
                  <div class="font-medium"><?php echo e($item->drug->name); ?></div>
                  <div class="text-xs text-[var(--muted)]"><?php echo e($item->drug->generic_name ?? ''); ?></div>
                </td>
                <td class="py-2"><?php echo e(number_format($item->unit_price, 2)); ?></td>
                <td class="py-2">
                  <form method="POST" action="<?php echo e(route('pharmacy.cart.update', $item)); ?>" class="flex items-center gap-2">
                    <?php echo csrf_field(); ?>
                    <input type="number" name="quantity" min="1" value="<?php echo e($item->quantity); ?>" class="input w-10">
                    <button class="btn h-9 px-3 rounded-xl bg-[var(--brand)] text-white">تحديث</button>
                  </form>
                </td>
                <td class="py-2"><?php echo e(number_format($item->quantity * $item->unit_price, 2)); ?></td>
                <td class="py-2">
                  <form method="POST" action="<?php echo e(route('pharmacy.cart.remove', $item)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn h-9 px-3 rounded-xl bg-red-600 text-white">حذف</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <?php endif; ?>

  <?php if (! ($hasAny)): ?>
    <div class="text-center text-[var(--muted)] py-10">سلتك فارغة.</div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', ['title' => 'سلة المشتريات'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alzur\Desktop\Madness\learning laravel\Projects\Laravel\resources\views/pharmacy/cart.blade.php ENDPATH**/ ?>