

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="mb-4 rounded-lg border border-[var(--line)] bg-green-50 px-4 py-3 text-sm text-green-700">
      <?php echo e(session('status')); ?>

    </div>
  <?php endif; ?>

  <div class="flex items-center justify-between mb-4">
    <h1 class="text-xl font-bold text-[var(--brand-ink)]">مجموعات الأدوية</h1>
    <a href="<?php echo e(route('company.groups.create')); ?>" class="btn px-4 py-2 rounded-xl bg-[var(--brand)] text-white">إنشاء مجموعة</a>
  </div>

  <div class="overflow-x-auto">
    <table class="min-w-full text-sm">
      <thead class="text-[var(--muted)]">
        <tr class="border-b border-[var(--line)]">
          <th class="py-3 text-right">#</th>
          <th class="py-3 text-right">العنوان</th>
          <th class="py-3 text-right">الحالة</th>
          <th class="py-3 text-right">عدد الأدوية</th>
          <th class="py-3 text-right">آخر تحديث</th>
          <th class="py-3 text-right">إجراءات</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="border-b border-[var(--line)]">
            <td class="py-3"><?php echo e($g->id); ?></td>
            <td class="py-3"><?php echo e($g->title ?? '—'); ?></td>
            <td class="py-3">
              <span class="inline-block rounded-md border px-2 py-0.5 text-xs
                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                  'bg-yellow-50 border-yellow-200 text-yellow-700' => $g->status === 'draft',
                  'bg-blue-50 border-blue-200 text-blue-700'       => $g->status === 'submitted',
                  'bg-green-50 border-green-200 text-green-700'    => $g->status === 'published',
                  'bg-gray-50 border-gray-200 text-gray-600'       => $g->status === 'archived',
                ]); ?>"
              "><?php echo e(__("{$g->status}")); ?></span>
            </td>
            <td class="py-3"><?php echo e($g->drugs()->count()); ?></td>
            <td class="py-3"><?php echo e($g->updated_at?->diffForHumans()); ?></td>
            <td class="py-3">
              <a href="<?php echo e(route('company.groups.show',$g)); ?>" class="text-[var(--brand-ink)] hover:underline">عرض</a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" class="py-6 text-center text-[var(--muted)]">لا توجد مجموعات بعد.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="mt-4"><?php echo e($groups->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', ['title' => 'مجموعات الأدوية'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alzur\Desktop\Madness\learning laravel\Projects\Laravel\resources\views/company/groups/index.blade.php ENDPATH**/ ?>