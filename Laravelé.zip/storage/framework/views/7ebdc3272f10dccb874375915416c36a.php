

<?php $__env->startSection('content'); ?>
  
  <?php if(session('success')): ?>
    <div class="mb-4 rounded-xl border-2 border-[var(--ink)] bg-[var(--bg-card)] p-3 text-[var(--brand-ink)]">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

  
  <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-5">
    <form class="flex items-center gap-2" method="GET" action="<?php echo e(route('company.orders.index')); ?>">
      <input type="text" name="q" value="<?php echo e($search); ?>" placeholder="بحث برقم الطلب أو اسم الصيدلية" class="input w-64">
      <select name="status" class="input w-48">
        <option value="">كل الحالات</option>
        <?php $__currentLoopData = ['pending'=>'قيد المراجعة','confirmed'=>'تم التأكيد','preparing'=>'جارِ التجهيز','out_for_delivery'=>'خرج للتسليم','completed'=>'مكتمل','cancelled'=>'ملغي']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($key); ?>" <?php if($status===$key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <button class="btn h-11 px-4 rounded-xl">تصفية</button>
    </form>

    
    <div class="flex flex-wrap gap-2 text-xs">
      <?php $__currentLoopData = ['pending'=>'قيد المراجعة','confirmed'=>'تم التأكيد','preparing'=>'جارِ التجهيز','out_for_delivery'=>'خرج للتسليم','completed'=>'مكتمل','cancelled'=>'ملغي']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="rounded-xl border-2 border-[var(--ink)] px-3 py-1 bg-[var(--bg-card)]">
          <?php echo e($label); ?>: <?php echo e($counts[$k] ?? 0); ?>

        </span>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

  
  <?php if($orders->isEmpty()): ?>
    <div class="text-center text-[var(--muted)] py-16">لا توجد طلبيات حالياً.</div>
  <?php else: ?>
    <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="rounded-2xl border border-[var(--line)] bg-[var(--bg-card)] shadow-soft p-4">
          <div class="flex items-center justify-between">
            <div class="text-[var(--brand-ink)] font-semibold">طلب #<?php echo e($order->id); ?></div>
            <span class="text-xs rounded-lg border-2 border-[var(--ink)] px-2 py-0.5 bg-[var(--bg-page)]">
              <?php echo e(__("statuses.$order->status") ?? $order->status); ?>

            </span>
          </div>

          <div class="mt-2 text-sm text-[var(--muted)]">
            <div>الصيدلية: <?php echo e($order->pharmacy->name ?? '—'); ?></div>
            <div>الإجمالي: <?php echo e(number_format($order->total_amount, 2)); ?></div>
            <div>بتاريخ: <?php echo e($order->created_at?->format('Y-m-d H:i')); ?></div>
          </div>

          
          <div class="mt-3 space-y-2">
            <?php $__currentLoopData = $order->items->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="flex items-center gap-2 text-sm">
                <?php $img = $item->drug->image_url ?? null; ?>
                <?php if($img): ?>
                  <img src="<?php echo e($img); ?>" class="h-8 w-8 rounded-lg object-cover border border-[var(--line)]" alt="">
                <?php else: ?>
                  <div class="h-8 w-8 rounded-lg border border-[var(--line)] bg-[var(--bg-page)]"></div>
                <?php endif; ?>
                <div class="truncate flex-1">
                  <div class="truncate"><?php echo e($item->drug->name ?? '—'); ?></div>
                  <div class="text-[10px] text-[var(--muted)]">x<?php echo e($item->quantity); ?> • <?php echo e(number_format($item->unit_price,2)); ?></div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($order->items->count() > 3): ?>
              <div class="text-xs text-[var(--muted)]">+ <?php echo e($order->items->count() - 3); ?> عناصر أخرى</div>
            <?php endif; ?>
          </div>

          <div class="mt-4 flex items-center justify-between gap-2">
            <a href="<?php echo e(route('company.orders.show', $order)); ?>" class="rounded-xl border-2 border-[var(--ink)] px-3 py-2 hover:bg-[var(--line)]/60 text-sm">
              تفاصيل الطلب
            </a>

            <form method="POST" action="<?php echo e(route('company.orders.updateStatus', $order)); ?>" class="flex items-center gap-2">
              <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
              <select name="status" class="input w-44">
                <?php $__currentLoopData = ['pending'=>'قيد المراجعة','confirmed'=>'تم التأكيد','preparing'=>'جارِ التجهيز','out_for_delivery'=>'خرج للتسليم','completed'=>'مكتمل','cancelled'=>'ملغي']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($key); ?>" <?php if($order->status===$key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <button class="btn h-10 px-3 rounded-xl text-sm">تحديث</button>
            </form>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-6">
      <?php echo e($orders->links()); ?>

    </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', ['title' => $title ?? 'إدارة الطلبيات'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alzur\Desktop\Madness\learning laravel\Projects\Laravel\resources\views/company/orders/index.blade.php ENDPATH**/ ?>