<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

// 👇 أضف هذا السطر:
use App\Http\Middleware\EnsureRole;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // 👇 سجل alias باسم 'role' يشير إلى كلاس EnsureRole
        $middleware->alias([
            'role' => EnsureRole::class,
        ]);

        // (اختياري) ممكن تضيف middlewares global أو groups هنا لاحقاً
        // $middleware->append(\Illuminate\Http\Middleware\HandleCors::class);
        // $middleware->web([...]);
        // $middleware->api([...]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
