<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\CustomAuthController;

// GET /login
Route::middleware('guest')->get('/login', [CustomAuthController::class, 'showLogin'])
    ->name('login');

// POST /login
Route::middleware('guest')->post('/login', [CustomAuthController::class, 'login'])
    ->name('login.post');

// POST /logout
Route::middleware('auth')->post('/logout', [CustomAuthController::class, 'logout'])
    ->name('logout');

// توجيه حسب الدور
Route::get('/redirect', function () {
    $role = auth()->user()->role ?? null;
    return match ($role) {
        'admin'    => redirect('/admin/dashboard'),
        'company'  => redirect('/company/dashboard'),
        'delivery' => redirect('/delivery/dashboard'),
        default    => redirect('/pharmacy/dashboard'),
    };
})->middleware('auth');
