<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <title>{{ $title ?? config('app.name', 'My Laravel App') }}</title>

    @vite('resources/css/app.css')
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">

    <style>
      :root{
        --font-ui: 'Tajawal', sans-serif;
        --bg-page: #f7f8fb;
        --bg-card: #ffffff;
        --ink: #243342;
        --muted: #6b7a90;
        --brand: #6aa5a9;   /* أخضر مزرق هادئ */
        --brand-ink: #0e2a2c;
        --line: #e8edf2;
      }
      html, body { height: 100%; }
      body{
        margin:0; padding:0;
        font-family: var(--font-ui);
        background: var(--bg-page);
        color: var(--ink);
      }
      .shadow-soft{ box-shadow: 0 6px 24px rgba(14, 42, 44, 0.06); }
    </style>
</head>
<body class="min-h-dvh flex flex-col">

    <!-- Navbar -->
    <header class="bg-[var(--bg-card)] border-b border-[var(--line)] shadow-soft">
      <div class="mx-auto w-full max-w-7xl px-4 sm:px-6">
        <div class="flex items-center justify-between h-16">
          <!-- Brand -->
          <a href="{{ url('/') }}" class="flex items-center gap-2 font-bold text-[var(--brand-ink)]">
<span class="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-[var(--brand)] text-[var(--brand-ink)]" aria-hidden="true">
  <!-- Bowl of Hygieia (cup & snake) -->
  <svg width="24" height=" 24" viewBox="0 0 24 24" fill="none"
       xmlns="http://www.w3.org/2000/svg" stroke="currentColor"
       stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
    <!-- Bowl -->
    <path d="M6 10h12c0 2.6-3.2 4.5-6 4.5S6 12.6 6 10Z"/>
    <!-- Stem -->
    <path d="M12 14.5V20"/>
    <!-- Base -->
    <path d="M9 20h6"/>
    <!-- Snake wrapping the bowl -->
    <path d="M15 5c-1.6 0-2.6.8-2.6 2s1 2 2.6 2H17c1.6 0 2.6.8 2.6 2s-1 2-2.6 2h-5.5"/>
    <!-- Snake head tip -->
    <path d="M17 5l2-1"/>
  </svg>
</span>

            <span>{{ config('app.name', 'My Laravel App') }}</span>
          </a>

          <!-- Mobile menu toggle (checkbox hack) -->
          <input id="nav-toggle" type="checkbox" class="hidden peer" />
          <label for="nav-toggle" class="md:hidden cursor-pointer p-2 rounded-lg hover:bg-[var(--line)]">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-[var(--ink)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
          </label>

          <!-- Links -->
          <nav class="hidden md:flex items-center gap-6 text-sm">
            <a class="text-[var(--ink)] hover:text-[var(--brand-ink)] transition" href="#">الرئيسية</a>
            <a class="text-[var(--ink)] hover:text-[var(--brand-ink)] transition" href="#">التقارير</a>
            @auth
              <a class="rounded-lg bg-[var(--brand)] text-white px-3 py-1.5 hover:opacity-90 transition" href="{{ route('logout') }}"
                 onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                تسجيل الخروج
              </a>
              <form id="logout-form" method="POST" action="{{ route('logout') }}" class="hidden">
                @csrf
              </form>
            @else
              <a class="rounded-lg bg-[var(--brand)] text-white px-3 py-1.5 hover:opacity-90 transition" href="{{ route('login') }}">
                دخول
              </a>
            @endauth
          </nav>
        </div>

        <!-- Mobile menu panel -->
        <div class="peer-checked:block hidden md:hidden pb-3">
          <div class="mt-2 flex flex-col gap-2 text-sm">
            <a class="px-3 py-2 rounded-lg hover:bg-[var(--line)]" href="#">الرئيسية</a>
            <a class="px-3 py-2 rounded-lg hover:bg-[var(--line)]" href="#">التقارير</a>
            @auth
              <a class="px-3 py-2 rounded-lg bg-[var(--brand)] text-white hover:opacity-90"
                 href="{{ route('logout') }}"
                 onclick="event.preventDefault(); document.getElementById('logout-form-mobile').submit();">
                تسجيل الخروج
              </a>
              <form id="logout-form-mobile" method="POST" action="{{ route('logout') }}" class="hidden">
                @csrf
              </form>
            @else
              <a class="px-3 py-2 rounded-lg bg-[var(--brand)] text-white hover:opacity-90" href="{{ route('login') }}">
                دخول
              </a>
            @endauth
          </div>
        </div>
      </div>
    </header>

    <!-- Main -->
    <main class="flex-1">
      <div class="mx-auto w-full max-w-7xl px-4 sm:px-6 py-8">
        {{-- مسافة علوية بسيطة + صندوق محتوى عام اختياري --}}
        <div class="bg-[var(--bg-card)] rounded-2xl p-6 border border-[var(--line)] shadow-soft">
          @yield('content') <!-- القسم الفارغ لعرض صفحاتك -->
        </div>
      </div>
    </main>

    <!-- Footer -->
    <footer class="mt-auto border-t border-[var(--line)] bg-[var(--bg-card)]">
      <div class="mx-auto w-full max-w-7xl px-4 sm:px-6 py-6 text-center text-sm text-[var(--muted)]">
        &copy; {{ now()->year }} {{ config('app.name', 'My Laravel App') }} — جميع الحقوق محفوظة.
      </div>
    </footer>

</body>
</html>
