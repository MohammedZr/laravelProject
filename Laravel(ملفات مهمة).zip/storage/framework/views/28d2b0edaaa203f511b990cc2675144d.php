

<?php $__env->startPush('head'); ?>
  <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-xl text-[var(--brand-ink)] mb-4">الطلبيات المسندة إليّ</h1>

  <?php if($deliveries->isEmpty()): ?>
    <div class="text-[var(--muted)]">لا توجد طلبيات مسندة حاليًا.</div>
  <?php else: ?>
    <div class="grid gap-4">
      <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $order = $delivery->order;
          $hasGeo = $order?->delivery_lat && $order?->delivery_lng;
        ?>

        <div class="rounded-2xl border border-[var(--ink)] bg-[var(--bg-card)] p-4 shadow-soft">
          <div class="flex items-center justify-between">
            <div class="text-[var(--brand-ink)]">طلب #<?php echo e($order->id); ?></div>
            <div class="text-xs rounded-lg border-2 border-[var(--ink)] px-2 py-0.5">
              <?php echo e(__("statuses.$order->status") ?? $order->status); ?>

            </div>
          </div>

          <div class="mt-3 grid sm:grid-cols-2 gap-3 text-sm">
            <div>
              <div class="text-[var(--muted)]">الصيدلية</div>
              <div><?php echo e($order->pharmacy->name ?? '—'); ?></div>
              <div class="text-[var(--muted)]"><?php echo e($order->pharmacy->email ?? ''); ?></div>
            </div>
            <div>
              <div class="text-[var(--muted)]">بيانات التسليم</div>
              <div>العنوان: <?php echo e($order->delivery_address_line ?? '—'); ?></div>
              <div>المدينة: <?php echo e($order->delivery_city ?? '—'); ?></div>
              <div>الهاتف: <?php echo e($order->delivery_phone ?? '—'); ?></div>
            </div>
          </div>

          <?php if($hasGeo): ?>
            <div class="mt-3">
              <div id="map-<?php echo e($order->id); ?>" class="w-full h-56 rounded-xl border border-[var(--ink)]"></div>
            </div>
          <?php else: ?>
            <div class="mt-3 text-xs text-[var(--muted)]">لا توجد إحداثيات. تواصل مع الشركة/الصيدلية لتأكيد الموقع.</div>
          <?php endif; ?>

          <div class="mt-4 flex items-center gap-2">
            <a class="btn h-10 px-4 rounded-xl bg-[var(--brand)] text-white"
               href="<?php echo e(route('delivery.tasks.show', $order)); ?>">تفاصيل الطلب</a>
            <?php if($hasGeo): ?>
              <a class="btn h-10 px-4 rounded-xl bg-[var(--brand-ink)] text-white"
                 target="_blank"
                 href="https://www.google.com/maps?q=<?php echo e($order->delivery_lat); ?>,<?php echo e($order->delivery_lng); ?>">
                 فتح في Google Maps
              </a>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-4">
      <?php echo e($deliveries->links()); ?>

    </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
  <script>
    <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $order = $delivery->order; ?>
      <?php if($order?->delivery_lat && $order?->delivery_lng): ?>
        (function(){
          const lat = <?php echo e($order->delivery_lat); ?>;
          const lng = <?php echo e($order->delivery_lng); ?>;
          const map = L.map('map-<?php echo e($order->id); ?>').setView([lat, lng], 15);
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);
          L.marker([lat,lng]).addTo(map);
        })();
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', ['title' => $title ?? 'مهامي'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alzur\Desktop\Madness\learning laravel\Projects\Laravel\resources\views/delivery/tasks/index.blade.php ENDPATH**/ ?>