

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="mb-4 rounded-lg border border-[var(--line)] bg-green-50 px-4 py-3 text-sm text-green-700">
      <?php echo e(session('status')); ?>

    </div>
  <?php endif; ?>

  <div class="flex flex-col gap-4">
    <div class="rounded-2xl border border-[var(--line)] bg-[var(--bg-card)] p-4">
      <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 class="text-xl font-bold text-[var(--brand-ink)]">
            <?php echo e($group->title ?? "مجموعة #{$group->id}"); ?>

          </h1>
          <p class="text-sm text-[var(--muted)]">الحالة: <b><?php echo e($group->status); ?></b> — تم الإنشاء <?php echo e($group->created_at->diffForHumans()); ?></p>
        </div>

        <div class="flex items-center gap-2">
          <?php if($group->status === 'draft'): ?>
            <form method="POST" action="<?php echo e(route('company.groups.submit',$group)); ?>">
              <?php echo csrf_field(); ?>
              <button class="btn h-10 px-4 rounded-xl bg-blue-600 text-white">إرسال للمراجعة</button>
            </form>
          <?php endif; ?>

          <?php if(in_array($group->status, ['draft','submitted'])): ?>
            <form method="POST" action="<?php echo e(route('company.groups.publish',$group)); ?>">
              <?php echo csrf_field(); ?>
              <button class="btn h-10 px-4 rounded-xl bg-green-600 text-white">نشر وتفعيل الأدوية</button>
            </form>
          <?php endif; ?>

          <?php if($group->status !== 'archived'): ?>
            <form method="POST" action="<?php echo e(route('company.groups.archive',$group)); ?>">
              <?php echo csrf_field(); ?>
              <button class="btn h-10 px-4 rounded-xl bg-gray-600 text-white">أرشفة</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div class="rounded-2xl border border-[var(--line)] bg-[var(--bg-card)] p-4">
      <div class="flex items-center justify-between mb-3">
        <h2 class="font-semibold text-[var(--ink)]">الأدوية في هذه المجموعة</h2>
        <a href="<?php echo e(route('company.drugs.create',$group)); ?>" class="btn px-3 py-2 rounded-xl bg-[var(--brand)] text-white">إضافة دواء</a>
      </div>

      <div class="overflow-x-auto">
        <table class="min-w-full text-sm">
          <thead class="text-[var(--muted)]">
            <tr class="border-b border-[var(--line)]">
              <th class="py-3 text-right">#</th>
              <th class="py-3 text-right">الاسم التجاري</th>
              <th class="py-3 text-right">المادة الفعّالة</th>
              <th class="py-3 text-right">الشكل/التركيز</th>
              <th class="py-3 text-right">العبوة</th>
              <th class="py-3 text-right">SKU</th>
              <th class="py-3 text-right">السعر</th>
              <th class="py-3 text-right">المخزون</th>
              <th class="py-3 text-right">الحالة</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $group->drugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr class="border-b border-[var(--line)]">
                <td class="py-3"><?php echo e($d->id); ?></td>
                <td class="py-3 font-medium"><?php echo e($d->name); ?></td>
                <td class="py-3"><?php echo e($d->generic_name ?? '—'); ?></td>
                <td class="py-3"><?php echo e($d->dosage_form ?? '—'); ?> — <?php echo e($d->strength ?? '—'); ?></td>
                <td class="py-3"><?php echo e($d->pack_size); ?> <?php echo e($d->unit ?? ''); ?></td>
                <td class="py-3"><?php echo e($d->sku ?? '—'); ?></td>
                <td class="py-3"><?php echo e(number_format($d->price, 2)); ?></td>
                <td class="py-3"><?php echo e($d->stock); ?></td>
                <td class="py-3">
                  <span class="inline-block rounded-md border px-2 py-0.5 text-xs
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                      'bg-green-50 border-green-200 text-green-700' => $d->is_active,
                      'bg-gray-50 border-gray-200 text-gray-600'   => !$d->is_active,
                    ]); ?>"
                  "><?php echo e($d->is_active ? 'مفعل' : 'غير مفعل'); ?></span>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr><td colspan="9" class="py-6 text-center text-[var(--muted)]">لا توجد أدوية بعد.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', ['title' => $group->title ?? "مجموعة #{$group->id}"], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alzur\Desktop\Madness\learning laravel\Projects\Laravel\resources\views/company/groups/show.blade.php ENDPATH**/ ?>