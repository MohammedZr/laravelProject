@extends('layouts.layout', ['title' => $title ?? 'مهامي'])

@push('head')
  <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css"/>
@endpush

@section('content')
  <h1 class="text-xl text-[var(--brand-ink)] mb-4">الطلبيات المسندة إليّ</h1>

  @if($deliveries->isEmpty())
    <div class="text-[var(--muted)]">لا توجد طلبيات مسندة حاليًا.</div>
  @else
    <div class="grid gap-4">
      @foreach($deliveries as $delivery)
        @php
          $order = $delivery->order;
          $hasGeo = $order?->delivery_lat && $order?->delivery_lng;
        @endphp

        <div class="rounded-2xl border border-[var(--ink)] bg-[var(--bg-card)] p-4 shadow-soft">
          <div class="flex items-center justify-between">
            <div class="text-[var(--brand-ink)]">طلب #{{ $order->id }}</div>
            <div class="text-xs rounded-lg border-2 border-[var(--ink)] px-2 py-0.5">
              {{ __("statuses.$order->status") ?? $order->status }}
            </div>
          </div>

          <div class="mt-3 grid sm:grid-cols-2 gap-3 text-sm">
            <div>
              <div class="text-[var(--muted)]">الصيدلية</div>
              <div>{{ $order->pharmacy->name ?? '—' }}</div>
              <div class="text-[var(--muted)]">{{ $order->pharmacy->email ?? '' }}</div>
            </div>
            <div>
              <div class="text-[var(--muted)]">بيانات التسليم</div>
              <div>العنوان: {{ $order->delivery_address_line ?? '—' }}</div>
              <div>المدينة: {{ $order->delivery_city ?? '—' }}</div>
              <div>الهاتف: {{ $order->delivery_phone ?? '—' }}</div>
            </div>
          </div>

          @if ($hasGeo)
            <div class="mt-3">
              <div id="map-{{ $order->id }}" class="w-full h-56 rounded-xl border border-[var(--ink)]"></div>
            </div>
          @else
            <div class="mt-3 text-xs text-[var(--muted)]">لا توجد إحداثيات. تواصل مع الشركة/الصيدلية لتأكيد الموقع.</div>
          @endif

          <div class="mt-4 flex items-center gap-2">
            <a class="btn h-10 px-4 rounded-xl bg-[var(--brand)] text-white"
               href="{{ route('delivery.tasks.show', $order) }}">تفاصيل الطلب</a>
            @if($hasGeo)
              <a class="btn h-10 px-4 rounded-xl bg-[var(--brand-ink)] text-white"
                 target="_blank"
                 href="https://www.google.com/maps?q={{ $order->delivery_lat }},{{ $order->delivery_lng }}">
                 فتح في Google Maps
              </a>
            @endif
          </div>
        </div>
      @endforeach
    </div>

    <div class="mt-4">
      {{ $deliveries->links() }}
    </div>
  @endif
@endsection

@push('scripts')
  <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
  <script>
    @foreach($deliveries as $delivery)
      @php $order = $delivery->order; @endphp
      @if($order?->delivery_lat && $order?->delivery_lng)
        (function(){
          const lat = {{ $order->delivery_lat }};
          const lng = {{ $order->delivery_lng }};
          const map = L.map('map-{{ $order->id }}').setView([lat, lng], 15);
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);
          L.marker([lat,lng]).addTo(map);
        })();
      @endif
    @endforeach
  </script>
@endpush
