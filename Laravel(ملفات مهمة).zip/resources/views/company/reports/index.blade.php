@extends('layouts.layout', ['title' => 'تقارير الشركة'])

@section('content')
  <h1 class="text-xl text-[var(--brand-ink)] mb-4">تقارير الشركة</h1>
  <p class="text-[var(--muted)]">هنا ستظهر تقارير المبيعات والطلبات… (لاحقًا).</p>
@endsection
