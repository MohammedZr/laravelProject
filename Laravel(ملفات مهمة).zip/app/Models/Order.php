<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
// app/Models/Order.php
protected $fillable = [
  'user_id','company_id','status','total_amount',
  'delivery_address_line','delivery_city','delivery_phone',
  'delivery_lat','delivery_lng',
];

protected $casts = [
  'total_amount' => 'decimal:2',
  'delivery_lat' => 'decimal:7',
  'delivery_lng' => 'decimal:7',
];

    public function items()    { return $this->hasMany(OrderItem::class); }
    public function pharmacy() { return $this->belongsTo(User::class, 'user_id'); }
    public function company()  { return $this->belongsTo(User::class, 'company_id'); }
    public function delivery()
{
    return $this->hasOne(Delivery::class);
}

}
