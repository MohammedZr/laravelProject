<?php

namespace App\Http\Controllers\Delivery;

use App\Http\Controllers\Controller;
use App\Models\Delivery;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TaskController extends Controller
{
    // عرض كل المهام الخاصة بالمندوب الحالي
   public function index()
{
    $me = Auth::user();

    $deliveries = Delivery::with([
        'order' => function ($q) {
            $q->select(
                'id',
                'user_id',
                'company_id',
                'status',
                'total_amount',
                'created_at',
                'delivery_address_line',
                'delivery_city',
                'delivery_phone',   // ← الاسم الصحيح
                'delivery_lat',
                'delivery_lng'
            );
        },
        'order.pharmacy:id,name',
        'order.company:id,name',
    ])
    ->where('delivery_user_id', $me->id)
    ->latest()
    ->paginate(12);

    return view('delivery.tasks.index', [
        'title'      => 'مهامي',
        'deliveries' => $deliveries,
    ]);
}


    // عرض مهمة مفردة
   public function show(Delivery $delivery)
{
    $this->authorizeDelivery($delivery);

    $delivery->load([
        'order' => function ($q) {
            $q->select(
                'id',
                'user_id',
                'company_id',
                'status',
                'total_amount',
                'created_at',
                'delivery_address_line',
                'delivery_city',
                'delivery_phone',   // ← الصحيح
                'delivery_lat',
                'delivery_lng'
            );
        },
        'order.pharmacy:id,name',
        'order.company:id,name',
        'order.items.drug:id,name,generic_name'
    ]);

    return view('delivery.tasks.show', [
        'title'    => "طلب #{$delivery->order_id}",
        'delivery' => $delivery,
    ]);
}

    public function accept(Delivery $delivery)
    {
        $this->authorizeDelivery($delivery);

        if ($delivery->status === 'assigned') {
            $delivery->update(['status' => 'accepted']);
        }

        return back()->with('ok', 'تم قبول المهمة.');
    }

    public function pickup(Delivery $delivery)
    {
        $this->authorizeDelivery($delivery);

        if (in_array($delivery->status, ['accepted','assigned'], true)) {
            $delivery->update(['status' => 'picked_up']);
        }

        return back()->with('ok', 'تم استلام الشحنة.');
    }

    public function complete(Delivery $delivery)
    {
        $this->authorizeDelivery($delivery);

        $delivery->update([
            'status'       => 'delivered',
            'delivered_at' => now(),
        ]);

        // تحديث حالة الطلب إلى مكتمل
        $delivery->order?->update(['status' => 'completed']);

        return back()->with('ok', 'تم تسليم الطلب بنجاح.');
    }

    public function cancel(Delivery $delivery)
    {
        $this->authorizeDelivery($delivery);

        $delivery->update(['status' => 'cancelled']);

        return back()->with('ok', 'تم إلغاء المهمة.');
    }

    private function authorizeDelivery(Delivery $delivery): void
    {
        if ($delivery->delivery_user_id !== Auth::id()) {
            abort(403);
        }
    }
}
