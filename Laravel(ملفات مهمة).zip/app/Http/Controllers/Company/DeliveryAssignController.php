<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\Delivery;
use App\Models\Order;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DeliveryAssignController extends Controller
{
    public function assign(\Illuminate\Http\Request $request, \App\Models\Order $order)
{
    // يمنع الإسناد لو بيانات التسليم ناقصة
    if (!$order->delivery_address_line || !$order->delivery_phone) {
        return back()->with('error', 'لا يمكن الإسناد: بيانات التسليم (العنوان/الهاتف) غير مكتملة.');
    }

    $data = $request->validate([
        'delivery_user_id' => ['required','exists:users,id'],
    ]);

    // تأكد أن الحالة منطقية (اختياري)
    if (!in_array($order->status, ['confirmed','preparing','out_for_delivery','pending'], true)) {
        return back()->with('error', 'لا يمكن الإسناد في هذه الحالة الحالية للطلب.');
    }

    \App\Models\Delivery::updateOrCreate(
        ['order_id' => $order->id],
        [
            'company_user_id'  => auth()->id(),
            'delivery_user_id' => $data['delivery_user_id'],
            'status'           => 'assigned',
        ]
    );

    // (اختياري) لو أردت ضبط حالة الطلب مباشرة
    if ($order->status === 'pending') {
        $order->update(['status' => 'confirmed']);
    }

    return back()->with('ok', 'تم إسناد الطلب للمنذوب بنجاح.');
}

    public function unassign(Order $order)
    {
        if ($order->company_id !== Auth::id()) abort(403);

        $order->delivery()?->delete();
        // رجّع حالة الطلب لو تحب
        $order->update(['status' => 'confirmed']);

        return back()->with('ok', 'تم فك الإسناد.');
    }
}
