@extends('layouts.layout')
@section('content')
{{-- تضمين الـمحتوى للصفحةا لرئيسة داخل القالب الاصلي الدرس رقم 16 --}}
<div class="d-flex justify-content-center align-items-center min-vh-100 text-center flex-column">
    <h1>مرحباً بك في الصفحة الرئيسية</h1>
    <p>هذه هي الصفحة الرئيسية لفارما نت.</p>
</div>
@endsection